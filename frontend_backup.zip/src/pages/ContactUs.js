import React from "react";
// import "../../node_modules/bootstrap/dist/css/bootstrap.css";

// import Dipak from "../img/Dipak.jpg";
// import Pramod from "../img/Pramod.jpg";
// import Janhavi from "../img/Janhavi.jpg";
// import Vrushali from "../img/Vrushali.jpg";

function ContactUs() {
  return (
        <div style={{"content-align":"left" ,"margin":"100px"}}>
          <div>
          <h1>Contact Us</h1>
          <p>Online Pizza Store</p>
            Email: pizzastore@gmail.com<br></br>
            Phone: 9860123456<br></br>
            Address: Hinjewadi, Phase-2, Pimpri, India<br></br>
          </div>
        </div>
  );
}

export default ContactUs;
