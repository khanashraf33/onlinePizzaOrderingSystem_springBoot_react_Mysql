import React from 'react'
import AdminNav from '../AdminNav';


const Contact = () => {
 
    return (
        <>
        <AdminNav/>
          <div className='home-page'>
            <div className='home-div'>
              
              <h1>Contact us</h1>
            </div>
          </div>  
        </>
    )
}

export default Contact;