package com.pizzadelivery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinePizzaDeliveryApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinePizzaDeliveryApplication.class, args);
	}

}
