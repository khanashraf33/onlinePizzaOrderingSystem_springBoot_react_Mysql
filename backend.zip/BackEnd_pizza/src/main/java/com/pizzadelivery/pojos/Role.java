package com.pizzadelivery.pojos;

public enum Role {
	CUSTOMER, DELIVERYPARTNER, ADMIN, MANAGER
}
