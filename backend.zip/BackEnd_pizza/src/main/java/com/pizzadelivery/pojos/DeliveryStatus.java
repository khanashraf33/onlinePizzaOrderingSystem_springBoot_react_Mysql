package com.pizzadelivery.pojos;

public enum DeliveryStatus {
	PLACED, CONFIRMED, COOKING, OUTFORDELIVERY, DELIVERED
}
