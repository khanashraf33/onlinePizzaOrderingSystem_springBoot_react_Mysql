import React from 'react'
import '../App.css';

function CartBar() {
  return (
    <div className='cart-area'>
        <h1>User Cart</h1> 
    </div>
  )
}

export default CartBar