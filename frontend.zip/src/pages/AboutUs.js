import React from 'react'

function AboutUs() {
  return (
    <div style={{"content-align":"left" ,"margin":"100px"}}>
        <h1>About Us</h1>
    ORDER PIZZA ONLINE FROM DOMINOS FOR YOUR VIRTUAL PIZZA PARTY
    Are you longing for a pizza with friends and family? You can celebrate, mope, or make a dull day better with Pizzateria pizza. Put your feet up and dig into the cheesy goodness of the pizza and gulp your worries down with the beverages. Download the app and get food delivery at your doorstep to start your perfect evening.
    <br></br>
    BULK ORDERS FOR OCCASIONS
    Pizzateria has provided the incredible option of scheduling when you want your pizza. Whether you are hosting a birthday party or a ladies’ night, you need not worry about the food. Place your order in advance and let Pizzateria take care of showing up on time with your hot and steamy pizzas. There is nothing better than a slice of authentic Italian food to make your party a success.
    <br></br>
    Pizzateria PIZZA PARTIES AT BANQUETS
    While hosting a party at any of the banquets, don’t you wish you would have the option of enjoying the cheesilicious pizza at Pizzateria? Pizzateria has heard your hearts’ wishes and made that possible too! You can now go for the pizza delivery and get it delivered at the banquets. Enjoy every bite with friends because the more the merrier.
    {/* <br></br>
    OUTDOOR CATERING WITH Pizzateria PIZZA
    The memorable part of a party is the food and beverage options. The next factor which comes close is the food service! With Pizzateria, you can now experience all the options from a virtual pizza party with your colleagues and friends to the exquisite outdoor catering option that Pizzateria has curated. You can enjoy Pizzateria bounty of veg pizza, non veg pizza, stuffed crusts, specialty chicken, sides, and desserts. Get the warm and comfortable feeling of being at the Pizzateria restaurant near me, no matter where you are.
    <br></br>
    NO ONE DOES FOOD DELIVERY AND PIZZA DELIVERY BETTER THAN Pizzateria
    Pizzateria is committed to bringing you the best of food and service. Just like the food, the service is warm and the best of its class.
    <br></br>
    FOOD DELIVERY FROM YOUR FAVORITE EAT ZONE
    If you have ever opted for food delivery near me, you should know that Pizzateria pizza delivers food at your doorstep in just 30mins. Be careful when you accept the food delivery from the executive because it is sure to be piping hot! Lose yourself in the intoxicating smell of freshly baked pizza and gobble it down with the perfect blend of herbs. The efficient service makes Pizzateria one of the quickest amongst the nearby food delivery options.
    <br></br>
    PIZZA DELIVERY OF LOVE
    If you are a pizza-lover, then you know pizza home delivery is the best way to enjoy the pizza. Once your online pizza delivery order is placed, you can play with your pet or watch TV till the executive drops off the divine pie. The only one who loves pizza delivery more than you is probably your pet, who is glad you stayed in! Get the toasty pizzas and wash them down with the great beverage options and end your evening with the most amazing desserts.
    <br></br>
    FOOD SERVICE BY Pizzateria FOR A SMOOTH EVENT
    Worried about the food service at your upcoming party? Well, rest assured because Pizzateria has got food catering services that will ensure a seamless event. If you are looking for a food service near me, just log onto Pizzateria website and enquire regarding the same.
    <br></br>
    IMPECCABLE CATERING SERVICE FOR YOUR EVENT
    The thing that is remembered by most in any wedding, is the wedding catering services. Pizzateria has got your back in this event and any other party, to ensure you have the best catering service your guests have seen. The professionalism, competence, and warmth of the catering services, will make your job as a host much easier. If you are looking for catering services near me, Pizzateria is the place to begin. Whether it is a bachelorette party catering or birthday catering, Pizzateria is the way to ensure you are stress-free and enjoy the party. With a great selection of beverages, options of veg and non veg pizza, and sides, your guests will keep trying new things till they leave! Don’t forget the innovative items like burger pizza that will keep things interesting. Pizzateria is already the best at virtual pizza party and now you can bring that joy to your party at a venue too!
    <br></br>
    BULK ORDER FOOD & BEVERAGES ONLINE FROM YOUR NEAREST Pizzateria STORE
    With a promise to deliver tasty food and the best quality food, Pizzateria is the go-to place for authentic culinary treats.
    <br></br>
    THE JOY OF ITALIAN FOOD AT YOUR DOORSTEP
    Authentic Italian food is delightful and can turn around the mood and lift spirits as nothing can. The most famous Italian food loved all over the world is pizza and pasta. The creamy bowl of pasta at Pizzateria will take you to the exotic lanes of Italy. The freshness and crunch of veggies and tenderness of meats on the pizza, make Pizzateria the top contender for the best Italian food near me. The magic of this food can be experienced at the banquets near me whenever you are planning a gathering. Get the best of Pizzateria at banquets whether it is a corporate event or a private party!
    <br></br>
    GET THE MOST OPTIONS OF FOOD AND BEVERAGES WITH Pizzateria
    Food and beverage are the foundation of any memorable event and are enough to woo guests. The food and beverage service as well the range of options are equally important or the guests may be put off and you may have to face negative feedback. Whether you wish to cater for guests at a school reunion or the pre-wedding festivities, as the host, food and beverages are your top priority. The guests should feel welcome and well taken care of at the same time. If you are looking to host a virtual pizza party, then Pizzateria has got you covered too. Nothing having a bowl of pasta or digging into some dessert in the virtual company of your friends. Pizzateria is known for hospitality whether you ask for home delivery or catering. The relentless pursuit of excellence is what sets Pizzateria apart. The tender chicken sides, garlic bread, yummy dips, parcels, and tacos are a part of the same delicious package.
    <br></br>
    EASY ORDERING AND EASY FOOD DELIVERY
    When you are planning that pizza party, you don’t have to think twice about the taste and quality because everyone knows Domino's has got it all. When you are planning your virtual pizza party, you can get in touch with Pizzateria beforehand and let your requirement be known. After that, all you need to do is place the order and pizza delivery time. And just like that, Pizzateria will deliver boxes of gooey delights to everyone. Dig into your pizza and chill!
    <br></br>
    VIRTUAL PIZZA PARTY WITH YOUR OFFICE PALS
    If you are looking to host an office pizza party with your pals, you can make use of the E-Gift voucher to unlock attractive discounts and save more. Pizzateria is set to bring the warmth of friendship to the virtual parties with the scrumptious and well-loved items on the menu. The magical touch of cheese burst crust can turn any meeting into a party! */}
    </div>
  )
}

export default AboutUs