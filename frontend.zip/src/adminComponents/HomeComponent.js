import React from 'react'
import AdminNav from '../AdminNav';


const HomeComponent = () => {
 
    return (
        <>
        <AdminNav/>
          <div className='home-page'>
            <div className='home-div'>
              
              <h1>Home</h1>
            </div>
            
          </div>  
         
        </>
    )
}

export default HomeComponent;