import React from 'react'
import AdminNav from '../AdminNav'


const AboutUsComponent = () => {
 
    return (
        <>
        <AdminNav/>
          <div className='home-page'>
            <div className='home-div'>
              
              <h1>About us</h1>
            </div>
          </div>  
        </>
    )
}

export default AboutUsComponent